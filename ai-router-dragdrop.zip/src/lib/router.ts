import { RouterInput, RouterOutputSchema, RouterResult } from "./types";
import { runMock } from "./providers/mock";
import { runSerpApi } from "./providers/serpapi";

/**
 * Provider selection:
 * - ROUTER_PROVIDER=serpapi | mock
 * Default: mock
 */
function getProvider(): string {
  return (process.env.ROUTER_PROVIDER || "mock").toLowerCase();
}

export async function runRouter(input: RouterInput): Promise<RouterResult> {
  const provider = getProvider();

  // Primary
  try {
    if (provider === "serpapi") {
      const { output, raw } = await runSerpApi(input);
      const validated = RouterOutputSchema.parse(output);
      return { ok: true, provider: "serpapi", output: validated, raw };
    }

    const { output, raw } = await runMock(input);
    const validated = RouterOutputSchema.parse(output);
    return { ok: true, provider: "mock", output: validated, raw };

  } catch (err: any) {
    // Fallback chain: mock always available
    try {
      const { output, raw } = await runMock(input);
      const validated = RouterOutputSchema.parse(output);
      return {
        ok: false,
        provider: `${provider}->mock`,
        error: err?.message ?? "Provider error",
        output: { ...validated, flags: Array.from(new Set([...(validated.flags || []), "FALLBACK_USED"])) },
        raw,
      };
    } catch (fallbackErr: any) {
      return {
        ok: false,
        provider: `${provider}->failopen`,
        error: `${err?.message ?? "Provider error"} | fallback: ${fallbackErr?.message ?? "Fallback error"}`,
        output: { summary: "", score: 0, flags: ["AI_DOWN", "FAILOPEN"], draft: "" },
        raw: null,
      };
    }
  }
}

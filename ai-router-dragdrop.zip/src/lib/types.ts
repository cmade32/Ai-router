import { z } from "zod";

export const RouterInputSchema = z.object({
  appId: z.string(),
  task: z.string(),
  input: z.string(),
  meta: z.record(z.any()).default({}),
});

export type RouterInput = z.infer<typeof RouterInputSchema>;

export const RouterOutputSchema = z.object({
  summary: z.string(),
  score: z.number().min(0).max(100),
  flags: z.array(z.string()),
  draft: z.string(),
});

export type RouterOutput = z.infer<typeof RouterOutputSchema>;

export type RouterResult = {
  ok: boolean;
  provider: string;
  output: RouterOutput;
  raw: any | null;
  error?: string;
};

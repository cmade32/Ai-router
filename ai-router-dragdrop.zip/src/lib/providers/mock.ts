import { RouterInput } from "../types";

/**
 * MOCK provider: Always returns something deterministic.
 * Replace this with any free LLM provider adapter later.
 */
export async function runMock(input: RouterInput): Promise<{ output: any; raw: any }> {
  const text = input.input || "";

  // Basic deterministic scoring example (replace with your real scoring)
  const score = Math.min(100, Math.max(0, Math.round(text.length / 20)));

  const output = {
    summary: text.slice(0, 220) + (text.length > 220 ? "..." : ""),
    score,
    flags: ["OK", "MOCK_PROVIDER"],
    draft: `Draft for ${input.appId}/${input.task}:\n\n${text.slice(0, 300)}${text.length > 300 ? "..." : ""}`,
  };

  return { output, raw: { note: "mock provider" } };
}

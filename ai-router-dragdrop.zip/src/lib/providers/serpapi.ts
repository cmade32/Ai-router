import { RouterInput } from "../types";

/**
 * SerpApi adapter (FREE-FIRST style)
 * - This is NOT an LLM. It is a data provider.
 * - For lead radars, you often want SEARCH + deterministic scoring.
 *
 * Env:
 * - SERPAPI_KEY
 *
 * NOTE: This is a minimal example using fetch to SerpApi's JSON endpoint.
 * You will likely customize it per platform (Google, Bing, Reddit, YouTube).
 */
export async function runSerpApi(input: RouterInput): Promise<{ output: any; raw: any }> {
  const key = process.env.SERPAPI_KEY;
  if (!key) throw new Error("Missing SERPAPI_KEY");

  // Minimal: treat input.input as query
  const q = input.input.slice(0, 400);

  const url = new URL("https://serpapi.com/search.json");
  url.searchParams.set("engine", "google");
  url.searchParams.set("q", q);
  url.searchParams.set("api_key", key);

  const r = await fetch(url.toString(), { method: "GET" });
  if (!r.ok) throw new Error(`SerpApi HTTP ${r.status}`);
  const data = await r.json();

  // Deterministic scoring placeholder:
  const hasResults = Array.isArray(data?.organic_results) && data.organic_results.length > 0;
  const score = hasResults ? 70 : 20;

  const top = data?.organic_results?.[0];
  const summary = top?.snippet || top?.title || "No results";

  const output = {
    summary: String(summary).slice(0, 300),
    score,
    flags: ["OK", "DATA_PROVIDER_SERPAPI"],
    draft: `Top result: ${top?.title ?? "N/A"}\n${top?.link ?? ""}`.trim(),
  };

  return { output, raw: data };
}
